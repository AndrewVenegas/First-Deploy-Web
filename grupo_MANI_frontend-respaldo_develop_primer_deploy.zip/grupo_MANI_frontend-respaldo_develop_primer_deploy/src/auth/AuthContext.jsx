// Esto nos permitirá recuperar variables y métodos que definimos
// mas alto en el arbol de componentes.

import { createContext } from "react";

export const AuthContext = createContext();
