const COLORES = [
    { nombre: "Negro", valor: "black" },
    { nombre: "Blanco", valor: "gray" },
    { nombre: "Rojo", valor: "red" },
    { nombre: "Verde", valor: "green" },
    { nombre: "Azul", valor: "blue" },
    { nombre: "Amarillo", valor: "yellow" },
    { nombre: "Naranja", valor: "orange" },
    { nombre: "Púrpura", valor: "purple" },
    { nombre: "Gris", valor: "gray" },
    { nombre: "Marrón", valor: "brown" },
    { nombre: "Cian", valor: "cyan" },
    { nombre: "Magenta", valor: "magenta" },
    { nombre: "Lima", valor: "lime" },
    { nombre: "Rosa", valor: "pink" },
    { nombre: "Verde azulado", valor: "teal" },
    { nombre: "Oliva", valor: "olive" },
    { nombre: "Azul marino", valor: "navy" },
    { nombre: "Granate", valor: "maroon" },
    { nombre: "Aguamarina", valor: "aquamarine" },
    { nombre: "Coral", valor: "coral" },
  ];

export default COLORES;