export default function Turnos() {
  return (
    <h1>Turnos</h1>
  )
}

