import CreateTurno from './CreateTurno';
import './ChoferMainPage.css'; 

export default function ChoferMainPage() {

    return (<>
       <CreateTurno />     

    </>
      
    )
  }