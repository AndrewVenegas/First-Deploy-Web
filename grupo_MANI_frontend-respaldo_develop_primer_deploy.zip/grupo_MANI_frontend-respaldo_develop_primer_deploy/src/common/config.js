const API_URL = 'https://api-turnosuc.onrender.com';

export default API_URL;