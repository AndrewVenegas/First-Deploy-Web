// Crear un notfoundpage.jsx
// con el isAdmin también vamos a tener problemas cuando se refresque la pagina

import './navbarStyles.css'

function NotFoundPage() {
  return (
    <>
      <h1> No se ha podido encontrar la página que buscas. </h1>
    </>
  )
}

export default NotFoundPage